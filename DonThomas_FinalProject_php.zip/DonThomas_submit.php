<!--
  Name : Don Thomas
  Purpose : Final Project
  Date : 13-08-2020
-->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Final Project</title>
  </head>
  <body >
  <!--Style tab-->
  <style>

    /*Style for text field */
    .styleField{
      width: 750px;
      height: 35px;
      font-size: larger;
      }

  </style>

  <!--div for main -->
  <div class="alert alert-primary" role="alert" style="text-align:center;height:1000px;">
    <!--Button for all data-->
    <button class="btn btn-warning" style="margin-top:50px;width: 200px;font-weight: 700;font-size: 20px;margin-bottom: 35px;"><a href="DonThomas_output.php">View all Records</a></button>
    <!--div for the form-->
    <div id="idDiv" class="classForm">
      <!--div & method-->
      <form action="DonThomas_output.php" method="post">
        
        <p style="font-weight: 1000;font-size: xx-large;margin-top: -40px;">Enter a Movie</p>
        <input type="text"  name="choice[]" class="styleField" placeholder="Film Name"><br>
        <label style="font-size: x-large;font-weight: 1000;">Rating of the Movie</label><br><br>
        <p style="margin: -25px 0px -15px 0px;">(1:Lowest - 5:Highest)</p><br>
        <select id="cars" name="choice[]" style="width: 100px;height: 30px;font-size: larger;margin-bottom: 10px;">
        <option value=1>1</option>
        <option value=2>2</option>
        <option value=3>3</option>
        <option value=4>4</option>
        <option value=5>5</option>
        </select><br>
        <!-- Submit Button-->
        <input type="submit" value="Submit" class="btn btn-success" style="width: 160px;font-weight: 900;font-size: 20px;">
      </form> 
    </div>
</div>


<!--Php tab for session display div-->
<?php
  session_start(); //session start
  //isset for cheching the value
  if(!isset($_SESSION['myName'])){
      //inside if
    }
    else
    { 
      //echo 'hereout'. $_SESSION['myName'];
        if($_SESSION['myName'] >= 2)
          {
            //div creation using script and its design
            echo '<script>document.getElementById("idDiv").innerHTML = "You have reached the maximum of 3 submissions. Please return later...!";</script>';
            echo '<style> .classForm{ background: palevioletred;height: 30px;} </style>';
            //echo 'here'. $_SESSION['myName'];
          }
        
    }


?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>


