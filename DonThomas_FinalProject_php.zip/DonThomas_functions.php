<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!--Style-->
<style>
    th{
        width: 400px;
        
    }
    table{
        margin: auto;
        padding-bottom:20px;
    }
    
</style>

<!--php tab for all  functions-->
<?php
//sanitize insert data
function sanitizeArray()
    {
        //clean using htmlentities and loop using foreach
        foreach ($_POST['choice'] as $key => $element) {
            // cleaned value stored in clean string
            $cleaned[$key] = htmlentities($element);
            //echo "$key : $element <br>";
        }
        //print_r($cleaned);
        return $cleaned;
    }

//fn insert
function fnInsert($newArray){

    session_start(); //session starting
    //echo 'imhere';

    //condition for session and incrementing
    if(!isset($_SESSION['myName'])){
        $_SESSION['myName']=0;
    }else
    {
        //echo $_SESSION['myName']. ' out';
        $_SESSION['myName']++;
    }

    
    //gettin date
    $today = date("Y-m-d h:m:s",time()); 

    //declare thr database details
    $localhost = 'localhost' ;
    $username = 'phpuser';
    $password ='phpuser';
    $database = 'summer2020';
    //connecting to database
    $mysqli = new mysqli($localhost, $username, $password, $database);
    //database insert query
    $sqli = "INSERT INTO `films` (`#`, `Film`, `Rating`, `Date`) VALUES (NULL, '$newArray[0]' , '$newArray[1]' , '$today')";
    //$sqli = "SELECT * FROM `film`";
    $result = mysqli_query($mysqli, $sqli);
    //var_dump($result);
    /*
    while($row = mysqli_fetch_row($result)){
        print_r($row);
      
    
    }
    */
    //echo for h3 message for inserting data
    echo'<h3 style="background: chartreuse;">Your entry was successfully inserted!</h3>';
    }
?>

<!--table creation-->
<table border = '2'>
<tr>
<th>id</th>
<th>Film</th>
<th>Rating</th>
<th>Date</th>
</tr>

<?php
    //display fn
    function fnDisplay(){
        //database connection
        $localhost = 'localhost' ;
        $username = 'phpuser';
        $password ='phpuser';
        $database = 'summer2020';

        //database connection
        $mysqli = new mysqli($localhost, $username, $password, $database);
        //select Query
        $sql = "SELECT * FROM `films`";
        //giving query
        $result = mysqli_query($mysqli, $sql);
    

        //display to the table giving values
        while($row = mysqli_fetch_row($result)){
            //print_r($row);
            echo "<tr>";
            echo "<td>" . $row[0] ."</td>";
            echo "<td>" . $row[1] . "</td>";
            echo "<td>" . $row[2] . "</td>";
            echo "<td>" . $row[3] . "</td>";
            echo "</tr>";
        
        
        }
        

    }

?>



    
</body>
</html>

