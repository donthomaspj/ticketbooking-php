-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2020 at 08:05 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `summer2020`
--

-- --------------------------------------------------------

--
-- Table structure for table `destinations`
--

CREATE TABLE `destinations` (
  `id` int(11) NOT NULL,
  `location` varchar(100) NOT NULL,
  `season` varchar(50) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `destinations`
--

INSERT INTO `destinations` (`id`, `location`, `season`, `price`) VALUES
(1, 'India', 'Fall', 10000),
(2, 'Canada', 'Winter', 2000),
(3, 'don', '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `films`
--

CREATE TABLE `films` (
  `#` int(11) NOT NULL,
  `Film` varchar(100) NOT NULL,
  `Rating` int(11) NOT NULL,
  `Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `films`
--

INSERT INTO `films` (`#`, `Film`, `Rating`, `Date`) VALUES
(1, 'Super-man', 4, '2020-12-20 20:20:20'),
(2, 'X-men', 4, '2020-12-20 20:20:20'),
(3, '11', 1, '2020-08-13 04:08:07'),
(4, '22', 1, '2020-08-13 04:08:13'),
(5, '33', 1, '2020-08-13 04:08:17'),
(6, 'Hulk', 5, '2020-08-13 11:08:11'),
(7, '', 1, '2020-08-14 12:08:06'),
(8, 'Iron-man', 3, '2020-08-14 12:08:50'),
(9, 'Iron-man', 3, '2020-08-14 12:08:17'),
(10, 'Iron-man', 3, '2020-08-14 12:08:04'),
(11, 'Iron-man', 3, '2020-08-14 12:08:46'),
(12, 'Iron-man', 3, '2020-08-14 01:08:34'),
(13, 'The King', 4, '2020-08-14 01:08:56'),
(14, 'Superman 2', 4, '2020-08-14 01:08:36'),
(15, 'Gorilla', 3, '2020-08-14 01:08:03'),
(16, 'Mummy', 4, '2020-08-14 01:08:19'),
(17, 'War', 2, '2020-08-14 01:08:36'),
(18, 'War 2', 4, '2020-08-14 01:08:53'),
(19, 'Hello', 4, '2020-08-14 07:08:15'),
(20, 'God', 5, '2020-08-14 08:08:05'),
(21, 'King', 5, '2020-08-14 08:08:21'),
(22, 'Queen', 1, '2020-08-14 08:08:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`#`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `destinations`
--
ALTER TABLE `destinations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `films`
--
ALTER TABLE `films`
  MODIFY `#` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
