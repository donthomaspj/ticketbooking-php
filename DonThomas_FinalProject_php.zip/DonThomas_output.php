<!--
  Name : Don Thomas
  Purpose : Final Project
  Date : 13-08-2020
-->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Final Project</title>
  </head>
  <body>
    <!--Main div-->
    <div class="alert alert-success" style="text-align:center;height:1000px;">
    <!--Button to back-->
    <button class="btn btn-warning" style="width: 160px;font-weight: 800;font-size: 26px;margin-bottom: 35px;"><a href="DonThomas_submit.php">Go Back</a></button>
    <!--php starting-->
    <?php
      //define a file
      define('ROOT',dirname(__FILE__));
      //echo ROOT;
      //file name for the fn call and new file
      include ROOT . '\DonThomas_functions.php';
     ?>
    <!--heading-->
    <h1>All Films Rating...!</h1>

    <pre>

      <!--php for post data-->
     <?php
      
      //var_dump($_POST['choice']);
      //if choice has value, new value inserted, else dislay the record
      if(isset($_POST['choice'][0]))
      {
            //print_r($_POST['choice'][0]);
            //new array
            $newArray = sanitizeArray();
            //array count
            $arrayCount = count($newArray);
            //echo $newArray[0];
            //fn calling for inserting
            fnInsert($newArray);
      }

      //fn for display
      fndisplay();
      
     ?>

    </pre>

    


</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>